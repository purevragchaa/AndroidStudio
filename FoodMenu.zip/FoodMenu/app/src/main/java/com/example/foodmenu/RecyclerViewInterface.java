package com.example.foodmenu;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
