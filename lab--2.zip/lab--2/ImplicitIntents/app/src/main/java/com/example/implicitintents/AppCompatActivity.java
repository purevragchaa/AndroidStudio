package com.example.implicitintents;

public class AppCompatActivity {
}
